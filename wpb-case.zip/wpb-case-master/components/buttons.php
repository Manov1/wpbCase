<?php if ($args['style'] == 'orange') { ?>
    <button type="button" class="text-white bg-primary hover:bg-warning focus:outline-none rounded-full text-sm px-4 py-3 text-center"><?php echo $args['text']; ?></button>
<?php } ?>