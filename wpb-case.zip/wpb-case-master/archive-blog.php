<?php defined('ABSPATH') || exit('Forbidden');

get_header();

?>
<div class="container">
    <h1>Blog archief</h1>
</div>
<?php

get_footer();
