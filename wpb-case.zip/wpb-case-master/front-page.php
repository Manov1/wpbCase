<?php defined('ABSPATH') || exit('Forbidden');

get_header();

while (have_posts()) {
    the_post();
?>


    <section class="overflow-hidden bg-gray-50 sm:grid sm:grid-cols-7 mx-auto flex max-w-7xl items-center justify-between py-20 px-20 xl:px-40">

        <div class=" col-span-3 mx-auto max-w-xl text-center sm:pr-6 sm:text-left rtl:sm:text-right">
            <h3 class="text-xl text-warning md:text-2xl">
                WP Brothers
            </h3>
            <h2 class="text-3xl font-bold text-gray-900 md:text-3xl">
                Welkom, WordPress Tovenaar!
            </h2>

            <p class="hidden text-gray-500 md:mt-4 md:block">
                Welkom bij WP Brothers, de plek waar jouw WordPress magie werkelijkheid wordt. Of je nu een CSS-kunstenaar bent, een PHP-guru of een plug-in pionier, wij zijn op zoek naar jou! Bereid je voor om deel uit te maken van een team waar innovatie en creativiteit hoog in het vaandel staan. Klaar om de uitdaging aan te gaan? Laten we samen de mooiste WordPress wonderen creëren!
            </p>
        </div>


        <img alt="" src="<?= get_template_directory_uri() ?>/assets/images/3a370dde00787da50c0c065d68c672423e24a9e5.jpg" class="col-span-4 h-56 w-full object-cover sm:h-full" />
    </section>

    <!-- 4 colums section -->
    <section class="overflow-hidden sm:grid sm:grid-cols-4 gap-x-5 mx-auto flex max-w-7xl w-full justify-between py-20 px-20 xl:px-40">
        <h2 class=" col-span-4 text-3xl font-bold text-center pb-10 md:text-3xl">
            Herkenbaar?
        </h2>
        <div class="col-span-1 text-center w-full">
            <i class="fas fa-ruler-horizontal h-12 mb-2" style="color: #f4a525;"></i>
            <h3 class="text-2xl leading-7 font-bold text-warning md:text-2xl">
                Creatieve Probleemoplosser
            </h3>
            <p class="hidden text-base md:mt-4 md:block">
                Je bent in staat om met out-of-the-box oplossingen te komen voor complexe uitdagingen. Geen enkele bug is veilig voor jouw innovatieve aanpak!
            </p>
        </div>
        <div class="col-span-1 text-center w-full">
            <i class="fas fa-play-circle h-12 mb-2" style="color: #f4a525;"></i>
            <h3 class="text-2xl leading-7 font-bold text-warning md:text-2xl">
                Koning(in) van de Plugins
            </h3>
            <p class="hidden text-base md:mt-4 md:block">
                Je hebt uitgebreide kennis van zowel populaire als obscure plugins en weet precies welke te gebruiken om een website naar een hoger niveau te tillen.
            </p>
        </div>
        <div class="col-span-1 text-center w-full">
            <i class="fas fa-layer-group h-12 mb-2" style="color: #f4a525;"></i>
            <h3 class="text-2xl leading-7 font-bold text-warning md:text-2xl">
                Flexibele Teamspeler
            </h3>
            <p class="hidden text-base md:mt-4 md:block">
                Je werkt net zo goed zelfstandig als in een team. Samenwerken met designers, marketeers en andere developers is voor jou een tweede natuur.
            </p>
        </div>
        <div class="col-span-1 text-center w-full">
            <i class="fas fa-pen-alt h-12 mb-2" style="color: #f4a525;"></i>
            <h3 class="text-2xl leading-7 font-bold text-warning md:text-2xl">
                Nieuwsgierige Lerner
            </h3>
            <p class="hidden text-base md:mt-4 md:block">
                Je bent altijd op de hoogte van de laatste trends en ontwikkelingen binnen de WordPress-community en past deze kennis toe in je werk.
            </p>
        </div>
    </section>

    <section class="overflow-hidden sm:grid sm:grid-cols-7 mx-auto flex max-w-7xl items-center justify-between py-20 px-20 xl:px-40">

        <div class="col-span-3 mx-auto max-w-xl text-center sm:pr-6 sm:text-left rtl:sm:text-right">
            <h3 class="text-xl text-warning md:text-2xl">
                Over ons
            </h3>
            <h2 class="text-3xl font-bold text-gray-900 md:text-3xl">
                Waarom WP Brothers
            </h2>

            <p class="hidden text-gray-500 md:mt-4 md:block">
                Bij WP Brothers draait alles om creativiteit, innovatie en samenwerking. Wij zijn een dynamisch team van WordPress fanaten die de grenzen van webontwikkeling opzoeken en verleggen. Werken bij ons betekent deel uitmaken van een hechte familie die samenwerkt om de beste WordPress-oplossingen te bieden aan onze klanten.
            </p>

            <a class="group inline-block rounded-full p-[2px] md:mt-4 focus:outline-none focus:ring active:text-opacity-75" href="#">
                <span class="block rounded-full bg-white border-warning text-warning font-semibold border px-4 py-3 text-sm group-hover:bg-transparent">
                    Over ons
                    <i class="fas fa-chevron-right ml-2" style="color: #f4a525;"></i>
                </span>
            </a>
        </div>


        <img alt="" src="<?= get_template_directory_uri() ?>/assets/images/2cbdc7b29b8b729db1b0ad933d96d3cbc1f83268.jpg" class="col-span-4 h-56 w-full object-cover sm:h-full" />
    </section>

    <section class="overflow-hidden bg-gray-50 sm:grid sm:grid-cols-7 mx-auto flex max-w-7xl items-center justify-between py-20 px-20 xl:px-40">
        <img alt="" src="<?= get_template_directory_uri() ?>/assets/images/3842730d227ca41a9eacec4c1ef38b12c1d9acfd.jpg" class="col-span-4 h-56 w-full object-cover sm:h-full" />

        <div class=" col-span-3 mx-auto max-w-xl text-center sm:pl-6 sm:text-left rtl:sm:text-right">
            <h3 class="text-xl text-warning md:text-2xl">
                Soliciteren
            </h3>
            <h2 class="text-3xl font-bold text-gray-900 md:text-3xl">
                Sluit je aan bij WP Brothers
            </h2>

            <p class="hidden text-gray-500 md:mt-4 md:block">
                Als je klaar bent om je carrière naar een hoger niveau te tillen en deel wilt uitmaken van een team dat streeft naar uitmuntendheid, dan is WP Brothers de plek voor jou. We zijn altijd op zoek naar getalenteerde WordPress developers die onze passie voor webontwikkeling delen. Kom en ontdek waarom werken bij WP Brothers niet zomaar een baan is, maar een avontuur vol kansen en groei.
            </p>

            <a class="group inline-block rounded-full p-[2px] md:mt-4 focus:outline-none focus:ring active:text-opacity-75" href="#">
                <span class="block rounded-full bg-white border-warning text-warning font-semibold border px-4 py-3 text-sm group-hover:bg-transparent">
                    Werken bij
                </span>
            </a>
        </div>
    </section>

    <section class="overflow-hidden sm:grid sm:grid-cols-3 gap-x-6 mx-auto flex max-w-7xl w-full justify-between py-20 px-20 xl:px-40">
        <div class="col-span-1 w-full">
            <img class="w-full h-48 object-cover" src="<?= get_template_directory_uri() ?>/assets/images/3842730d227ca41a9eacec4c1ef38b12c1d9acfd.jpg" />
            <h3 class="text-2xl leading-7 font-bold">
                Een Dag in het Leven van een WP Brothers Developer: Verwacht het Onverwachte!
            </h3>
            <div class="text-base md:mt-4 flex items-center">
                <p class="bg-warning rounded-full w-fit py-1 px-4 mr-3">Blog</p>
                <p class="w-fit mr-3"><i class="fas fa-map-marker-alt mr-2" style="color: #000000;"></i>Locatie</p>
                <p class="w-fit"><i class="fas fa-clock mr-2" style="color: #000000;"></i>Fulltime</p>
            </div>
        </div>
        <div class="col-span-1 w-full">
            <img class="w-full h-48 object-cover" src="<?= get_template_directory_uri() ?>/assets/images/3842730d227ca41a9eacec4c1ef38b12c1d9acfd.jpg" />
            <h3 class="text-2xl leading-7 font-bold">
                Waarom Werken bij WP Brothers Als WordPress Developer Jouw Beste Beslissing Ooit Zal Zijn
            </h3>
            <div class="text-base md:mt-4 flex items-center">
                <p class="bg-warning rounded-full w-fit py-1 px-4 mr-3">Blog</p>
                <p class="w-fit mr-3"><i class="fas fa-map-marker-alt mr-2" style="color: #000000;"></i>Locatie</p>
                <p class="w-fit"><i class="fas fa-clock mr-2" style="color: #000000;"></i>Fulltime</p>
            </div>
        </div>
        <div class="col-span-1 w-full">
            <img class="w-full h-48 object-cover" src="<?= get_template_directory_uri() ?>/assets/images/3842730d227ca41a9eacec4c1ef38b12c1d9acfd.jpg" />
            <h3 class="text-2xl leading-7 font-bold">
                Van Plugin-Problemen tot Klantensuccessen: Mijn Avonturen bij WP Brothers
            </h3>
            <div class="text-base md:mt-4 flex items-center">
                <p class="bg-warning rounded-full w-fit py-1 px-4 mr-3">Blog</p>
                <p class="w-fit mr-3"><i class="fas fa-map-marker-alt mr-2" style="color: #000000;"></i>Locatie</p>
                <p class="w-fit"><i class="fas fa-clock mr-2" style="color: #000000;"></i>Fulltime</p>
            </div>
        </div>
    </section>
<?php
}

get_footer();
