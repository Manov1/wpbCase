import "@fortawesome/fontawesome-free/js/solid.js";
import "@fortawesome/fontawesome-free/js/fontawesome.js";
import "./tailwind.css";

document.addEventListener("DOMContentLoaded", () => {
  console.log("DOM Loaded");
});
