<?php defined('ABSPATH') || exit('Forbidden'); ?>

<header>
  <div class="mx-auto flex max-w-7xl items-center justify-between py-6 px-20 xl:px-40">
    <div class="flex lg:flex-1">
      <a href="<?php echo get_bloginfo('wpurl'); ?>" class="-m-1.5 p-1.5">
        <span class="sr-only">WP Brothers</span>
        <img class="h-8 w-auto" src="<?= get_template_directory_uri() ?>/assets/images/Logo.png" alt="WP Brothers">
      </a>
    </div>
    <div class="hidden lg:flex lg:gap-x-12 items-center">
      <a href="#" class="text-sm leading-6 font-body text-gray-900">Blog</a>
      <div class="relative">
        <button type="button" class="flex items-center gap-x-2 text-sm leading-6 text-gray-900" aria-expanded="false">
          Dropdown
          <i class="fas fa-chevron-down" style="color: #FF470B;"></i>
        </button>

        <!--
          'Product' flyout menu, show/hide based on flyout menu state.

          Entering: "transition ease-out duration-200"
            From: "opacity-0 translate-y-1"
            To: "opacity-100 translate-y-0"
          Leaving: "transition ease-in duration-150"
            From: "opacity-100 translate-y-0"
            To: "opacity-0 translate-y-1"
        -->
      </div>
      <form class="max-w-md h-fit">
        <label for="default-search" class="text-sm sr-only">Zoeken</label>
        <div class="relative rounded border border-neutral-25">
          <div class="absolute inset-y-0 start-0 flex items-center ps-3 pointer-events-none">
            <i class="fas fa-search" style="color: #FF470B;"></i>
          </div>
          <input type="search" id="default-search" class="block w-full ps-10 py-2 px-3 text-sm outline-0 leading-6" placeholder="Zoeken naar..." required />
        </div>
      </form>
      <?php get_template_part('components/buttons', null, array('style' => 'orange', 'text' => 'Contact')); ?>
    </div>
</header>

<main>