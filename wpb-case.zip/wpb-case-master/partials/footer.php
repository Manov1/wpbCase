<?php defined('ABSPATH') || exit('Forbidden'); ?>

</main>

<footer>
  <div class="overflow-hidden bg-neutral-75 sm:grid lg:grid-cols-7 gap-x-10 mx-auto flex max-w-7xl w-full justify-between py-20 px-20 xl:px-40">
    <div class="col-span-3 grid text-message text-left">
      <img class="h-12 mb-8 w-auto" src="<?= get_template_directory_uri() ?>/assets/images/Logo-White.png" alt="WP Brothers">
      <a class="w-full text-xl font-normal mb-4">WP Brothers is een gespecialiseerd bureau op het gebied van het WordPress CMS en is onderdeel van Social Brothers.</a>
      <a class="w-full text-2xl font-bold underline mb-4">0307370902</a>
      <a class="w-full text-2xl font-bold underline mb-8">info@wpbrothers.nl</a>
    </div>
    <div class="col-span-3 grid grid-cols-3 text-message text-left">
      <div class="grid h-fit col-span-1">
        <a class="w-full text-xl font-normal mb-4">Heading</a>
        <a class="w-full text-base mb-4">label</a>
        <a class="w-full text-base mb-4">label</a>
        <a class="w-full text-base mb-4">label</a>
      </div>
      <div class="grid h-fit col-span-1">
        <a class="w-full text-xl font-normal mb-4">Heading</a>
        <a class="w-full text-base mb-4">label</a>
        <a class="w-full text-base mb-4">label</a>
        <a class="w-full text-base mb-4">label</a>
      </div>
      <div class="grid h-fit col-span-1">
        <a class="w-full text-xl font-normal mb-4">Heading</a>
        <a class="w-full text-base mb-4">label</a>
        <a class="w-full text-base mb-4">label</a>
        <a class="w-full text-base mb-4">label</a>
      </div>
    </div>
  </div>
  <div class="overflow-hidden bg-neutral-75 lg:grid lg:grid-cols-2 gap-x-6 mx-auto block max-w-7xl w-full justify-between py-6 px-20 xl:px-40">
    <div class="col-span-1 grid grid-rows-3 lg:gap-x-6 md:flex text-message text-base font-normal text-nowrap underline text-center lg:text-left">
      <a class="w-full">Algemene voorwaarden</a>
      <a class="w-full">Privacy statement</a>
      <a class="w-full">Toegankelijkheidsverklaring</a>
    </div>
    <div class="col-span-1 gap-x-4 flex justify-end">
      <i class="fab fa-facebook" style="color: #ffffff;"></i>
      <i class="fab fa-instagram" style="color: #ffffff;"></i>
      <i class="fab fa-linkedin" style="color: #ffffff;"></i>
      <i class="fab fa-twitter" style="color: #ffffff;"></i>
    </div>
  </div>
</footer>